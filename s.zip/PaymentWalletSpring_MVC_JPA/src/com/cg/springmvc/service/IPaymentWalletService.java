package com.cg.springmvc.service;

import com.cg.springmvc.dto.Customer;



public interface IPaymentWalletService
{
	public void createAccount(Customer customer);
	
	public void deposit(String custMobileNo, double amount);
	
	public void withdraw(String custMobileNo, double amount);
	
	public double checkBalance(String custMobileNo);
	
	public void fundTransfer(String sender, String reciever, double amount);


}
