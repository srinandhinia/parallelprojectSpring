package com.cg.springmvc.controller;

import java.util.Map;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvc.dto.Customer;
import com.cg.springmvc.service.IPaymentWalletService;


@Controller
public class MyController 
{
	@Autowired
	IPaymentWalletService paymentwalletservice;
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll() {
		return "home";
	}
	

	@RequestMapping(value="create", method=RequestMethod.GET)
	public String createAccount(@ModelAttribute("my") Customer cust, Map<String,Object> model) {
		System.out.println("in create");
		
		return "createaccount";
		
	}
	
	@RequestMapping(value="insertdata", method=RequestMethod.POST)
	public String insertData(@ModelAttribute("my") Customer cust, Map<String,Object> model) {
		/*int id=0;
		if(result.hasErrors())
		{
			return new ModelAndView("createaccount");
		}else {*/
		paymentwalletservice.createAccount(cust);
		System.out.println("insertdata");
		
		return "success";
	}
	

	@RequestMapping(value="deposit", method=RequestMethod.GET)
	public String depositAmount() {
		System.out.println("in deposit");
		
		return "deposit";
		
	}
	
	@RequestMapping(value="dodeposit", method=RequestMethod.GET)
	public String depositAmountData(@RequestParam("mbno") String mobNo,@RequestParam("damount") double depamount) 
	{
		
		paymentwalletservice.deposit(mobNo, depamount);
		System.out.println("dodeposit() retur success");
		return "success";
	}
	
	@RequestMapping(value="withdraw", method=RequestMethod.GET)
	public String withdrawAmount() {
		System.out.println("in withdraw");
		
		return "withdraw";
		
	}
	
	@RequestMapping(value="dowithdraw", method=RequestMethod.GET)
	public String withdrawAmountData(@RequestParam("mobno") String mobileNo,@RequestParam("withdrawamount") double withdamount) 
	{
		
		paymentwalletservice.withdraw(mobileNo, withdamount);
		System.out.println("dowithdraw() return success");
		return "success";
	}
	
	@RequestMapping(value="checkbalance", method=RequestMethod.GET)
	public String checkbal() {
		System.out.println("in withdraw");
		
		return "checkbalance";
		
	}
	
	@RequestMapping(value="docheckbalance", method=RequestMethod.GET)
	public ModelAndView checkBalInfo(@RequestParam("mobno") String mobileNo)
	{
		double bal=paymentwalletservice.checkBalance(mobileNo);
		
		return new ModelAndView("success","custdata",bal);
		
	}
	
	@RequestMapping(value="fundtransfer", method=RequestMethod.GET)
	public String fundtransfer() {
		System.out.println("in withdraw");
		
		return "fundtransfer";
		
	}
	@RequestMapping(value="dofundtransfer", method=RequestMethod.GET)
	public String fundTransferData(@RequestParam("senderMobNo") String senderMobileNo,
			@RequestParam("receiverMobNo") String receiverMobileNo,@RequestParam("transferAmount") double transferAmount) 
	{
		
		paymentwalletservice.fundTransfer(senderMobileNo, receiverMobileNo, transferAmount);;
		System.out.println("dowithdraw() return success");
		return "success";
	}
	
	

	

}
