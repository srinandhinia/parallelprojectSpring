package com.cg.springmvc.dao;

import com.cg.springmvc.dto.Customer;



public interface IPaymentWalletDao
{
	    public void createAccount(Customer customer);
		
		public void deposit(String custMobileNo, double amount);
		
		public void withdraw(String custMobileNo, double amount);
		
		public double checkBalance(String custMobileNo);
		
		public void fundTransfer(String sender, String reciever, double amount);

}
