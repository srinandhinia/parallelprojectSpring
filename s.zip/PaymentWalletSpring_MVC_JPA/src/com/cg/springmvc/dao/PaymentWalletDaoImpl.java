package com.cg.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.dto.Customer;

@Repository("paymentwalletdao")
public class PaymentWalletDaoImpl implements IPaymentWalletDao
{
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		entitymanager.persist(customer);
		entitymanager.flush();
		System.out.println("createAccountDaoImpl()");
	}

	@Override
	public void deposit(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		System.out.println("depositDaoImpl()");
		Customer customer = entitymanager.find(Customer.class, custMobileNo);
		double iniBal=customer.getInitialBalance();
		iniBal+=amount;
		customer.setInitialBalance(iniBal);
		entitymanager.flush();
		
	}

	@Override
	public void withdraw(String custMobileNo, double amount) {
		// TODO Auto-generated method stub
		Customer customer = entitymanager.find(Customer.class, custMobileNo);
		double iniBal=customer.getInitialBalance();
		iniBal-=amount;
		System.out.println(iniBal);
		customer.setInitialBalance(iniBal);
		entitymanager.flush();
		
	}

	@Override
	public double checkBalance(String custMobileNo) {
		// TODO Auto-generated method stub
		Customer cust = entitymanager.find(Customer.class, custMobileNo);
		double amt =cust.getInitialBalance();
		System.out.println(amt);
		return amt;
		
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		Customer cust1 = entitymanager.find(Customer.class, sender);
		double amt1 =cust1.getInitialBalance();
		Customer cust2 = entitymanager.find(Customer.class, reciever);
		double amt2 =cust2.getInitialBalance();
		amt1=amt1-amount;
		amt2=amt2+amount;
		cust1.setInitialBalance(amt1);
		cust2.setInitialBalance(amt2);
		
	}

}
